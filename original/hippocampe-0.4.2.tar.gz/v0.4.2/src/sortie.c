/*
 *  sortie.c
 *  Author(s) : Jérémy Pages <jeremy.pages@eleves.ec-nantes.fr>
 *  Copyright (C) 2008 Jérémy Pages
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Library General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#include <stdio.h>
#include <string.h>

#include "regles.h"

#define abs(n) ((n>=0)?n:-n)

extern FILE *flog;

/* enregistrement dans le fichier log */
 
void enregistrer(char* ligne)
{
    if(ligne != NULL)
    {
        fprintf(flog,"%s",ligne);
    }
}

/* envoi d'une commande à l'interface utilisateur */

void envoi(char* message)
{
    printf("%s%s",message,"\n");
    enregistrer(message);
}

void afficherPosition(struct Position p)
{
    int i,j;
    char c;

    for(i=r8+1;i>=r1-1;i--){
        for(j=A-1;j<=H+1;j++){
	    	switch(abs(p.diagramme[j][i])){
				case PION:
		    		c = 'P';
		    	break;
				case CAVALIER:
		    		c = 'C';
		    	break;
				case FOU:
		    		c = 'F';
		    	break;
				case TOUR:
		    		c = 'T';
		    	break;
				case DAME:
		    		c = 'D';
		    	break;
				case ROI:
		    		c = 'R';
		    	break;
				case VIDE:
		    		c = '.';
	    	}
 	    	if(p.diagramme[j][i]<0 && isalpha(c)) {
				c = tolower(c);
	    	}
	    	if(p.diagramme[j][i] == EXTERIEUR) {
	    		c = '*';
	    	}
	    	printf("%c",c);
		}
		printf("%c",'\n');
    }
    printf("%d%c",p.trait,'\n');
    printf("%d%c",p.pep,'\n');
    printf("%f%c",p.ccoups,'\n');
    printf("%d%c",p.roques,'\n');
}

void afficherEval(struct MVar mv)
{
    int i;
	
    printf("%s%d%s%d%c","eval=",mv.orig.eval," dep=",mv.orig.departage,'\n');
    for(i=0;i<mv.longueur;i++) {
	printf("%s%d%s%d%s%d%s%d%s%d%c","  coup ",i," : cd=",mv.variante[i].cd," ld=",mv.variante[i].ld,
                  " ca=",mv.variante[i].ca," la=",mv.variante[i].la,'\n');
    }
}
